#!/usr/bin/env python
# grep_some_condition.py
# https://stackoverflow.com/a/5463419

# 'package imports'
from remove_lines import remove_line

line = line.replace("test", "testZ")
line = line.replace("test", "testZ")
line = line.replace("test", "testZ")
line = line.replace("test", "testZ")
line = line.replace("test", "testZ")
line = line.replace("test", "testZ")
line = line.replace("test", "testZ")

remove_line(example_file.py)

# T test

# The lines below (#TT ... ) should be removed
# TT test
# TT test2
# TT test3
# TT test asdfasdf
