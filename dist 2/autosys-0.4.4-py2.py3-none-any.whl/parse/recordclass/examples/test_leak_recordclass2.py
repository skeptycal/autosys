#!/usr/bin/env python

# 'Standard Library'
import gc
import os
import random
import time

from collections import namedtuple

# 'package imports'
import psutil

from recordclass import recordclass


def memory_usage_psutil():
    # return the memory usage in percentage like top
    process = psutil.Process(os.getpid())
    mem = process.memory_percent()
    return mem


# X = recordclass('X', ['a','b','c'])
X = namedtuple("X", ["a", "b", "c"])

gc.collect()
time.sleep(1.0)
print(memory_usage_psutil())

lst = []
for i in range(1000000):
    a = X(1, 2, 3)
    lst.append(a)
t = tuple(lst)
del lst

gc.collect()
time.sleep(1.0)
print(memory_usage_psutil())

del t
gc.collect()
time.sleep(1.0)
print(memory_usage_psutil())
