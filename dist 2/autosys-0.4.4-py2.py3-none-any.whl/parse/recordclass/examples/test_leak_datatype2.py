#!/usr/bin/env python

# 'Standard Library'
import gc
import os
import time

from random import randint

# 'package imports'
import psutil

from recordclass import make_arrayclass, make_dataclass


def memory_usage_psutil():
    # return the memory usage in percentage like top
    process = psutil.Process(os.getpid())
    mem = process.memory_percent()
    return mem


N = 1000000
X = make_dataclass("X", fields=["a", "b", "c"])
Y = make_arrayclass("Y", fields=N)

gc.collect()
time.sleep(1.0)
print(memory_usage_psutil())

lst = Y()
for i in range(N):
    lst[i] = X(1, 2, 3)

gc.collect()
time.sleep(1.0)
print(memory_usage_psutil())

del lst
del Y
del X
gc.collect()
time.sleep(1.0)
print(memory_usage_psutil())
