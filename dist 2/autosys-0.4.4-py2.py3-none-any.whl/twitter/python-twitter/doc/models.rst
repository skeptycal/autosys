Models
======

Python-twitter provides the following models of the objects returned by the Twitter API:

* :py:class:`twitter.models.Category`
* :py:class:`twitter.models.DirectMessage`
* :py:class:`twitter.models.Hashtag`
* :py:class:`twitter.models.List`
* :py:class:`twitter.models.Media`
* :py:class:`twitter.models.Status`
* :py:class:`twitter.models.Trend`
* :py:class:`twitter.models.Url`
* :py:class:`twitter.models.User`
* :py:class:`twitter.models.UserStatus`
