"""\
This setup.py was provided by `package`, the Python package package package.

See http://pypi.python.org/pypi/package/ for more information.
"""

# 'Standard Library'
import sys

# 'package imports'
import package

sys.path.insert(0, "")

package.setup()
