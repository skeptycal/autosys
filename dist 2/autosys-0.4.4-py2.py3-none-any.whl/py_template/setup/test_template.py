#!/usr/bin/env python3
# -*- encoding: utf-8 -*-
""" module test_template.py - test """
# 'Standard Library'
import cProfile
import os
import random
import sys

from typing import Any, Dict, List, Tuple

###############################################################################
# pylint: disable=missing-docstring

###############################################################################

# ! Set testflag to True to run tests ...
# !   or set test_flag = True in calling program
testflag: bool = False

###############################################################################
# test variables used to store temporary function parameters
test_pattern: str = ""
test_filename: str = ""
test_list: List[str]
# used to catch function return results
return_list: List[str] = []
# used to catch errors in functions
e: Exception = None
###############################################################################


def function_test_args(
    args: List[str] = sys.argv[1:],
) -> List[str]:  # pylint: disable=dangerous-default-value
    """ function_test_args - faux test args (pointless passthrough to list)

    Returns:
        List [str] -- list of args
    """
    return_result: List[str] = []
    return_result = [
        str(args.index(value)) + ": " + str(value) for value in args
    ]
    return return_result


if __name__ == "__main__":

    print("Example Script for ", sys.argv[0])
    #########################################################
    test_list = sys.argv[:]
    test_pattern = "".join(test_list)
    print("Test Pattern: ", test_pattern)
    print("Test List: ", test_list)
    print()
    if testflag:
        # Place tests here
        # Thorough testing with edge cases preferred
        # A/B timing tests report comparison results
        pass

    else:
        # default operation
        print("Script result:")
        return_list = function_test_args(test_list)
        for i in return_list:
            print(i)
