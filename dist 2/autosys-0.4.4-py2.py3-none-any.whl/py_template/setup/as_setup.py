#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
as_setup.py
"""
# copyright (c) 2019 Michael Treanor
# https://www.github.com/skeptycal
# https://www.twitter.com/skeptycal
