import requests
import lxml
from bs4 import BeautifulSoup as soup

data = requests.get(
    'https://www.signalboosters.com/blog/best-smartphone-apps-to-find-your-cell-signal-strength/')


soup.
soup.get_text()
