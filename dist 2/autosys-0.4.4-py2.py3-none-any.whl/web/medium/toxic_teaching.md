# Top 5 Toxic Topics in Teaching

## I grieve for the loss of our rigorous and creative public schools. 

>Who the hell are you to tell us what is toxic and what is not? What do you know about teaching, anyway?

To comfort the hall monitors and internet guard dogs, I feel responsible for answering this question. Education is a hot topic lately. It always is. The 15 year process we call 'education' is a very long time to allow our children to be exposed to a system that is dysfunctional. There are also too many ignorant opinions floating around. It is important to hear from people who have actually created successful teaching experiences for real students.

---

>What does a successful outcome look like?

I suppose everyone has their own mental picture of a well educated 18 year old, some less flattering than others. We could include specific courses or electives. We could espouse certain value systems or cultural norms. These are fine goals and they are definitely a part of a successful school experience … but they are not the ultimate goal. 
My most basic definition is this:
A well educated young person should know how to work well alone or with others, in an efficient manner, to create something useful or valuable as a contribution to our society or the world.
Loss of culture
Damage to students
Quality of teachers
Parents are cheated … How we are allowing our children to be treated.
Not working! And how are we doing measured against the stated 'goals?'



Sadly, I no longer get to mentor new teachers. I grieve for loss of the creative bastions of learning that I recall from a few decades ago.
The problem, at least in the US, is that education has been vilified and the work of good teachers is neither appreciated or desired at this point in time. This really deserves its own blog post, and maybe I will share it someday, but after being a teacher for 20 years, I can say for sure that the public education industry is a toxic place right now. It is not attracting top talent any more. It is not reaching any of the goals set forth. I am on the verge of saying that most students are better off avoiding public schools at all costs. Most of the really good teachers I know are either taking early retirement (as I did), moving to private schools (along with a large pay cut), or soldiering on through the toxic environment that shows no signs of improving.
