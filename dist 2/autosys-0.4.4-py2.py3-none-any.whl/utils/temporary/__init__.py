# pylint: disable=invalid-name
# 'package imports'
import temporary.directories
import temporary.files

temp_file = temporary.files.temp_file
temp_dir = temporary.directories.temp_dir
in_temp_dir = temporary.directories.in_temp_dir
