#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# 'Standard Library'
import sys

args = sys.argv[1:]
for arg in args:
    print(" - ", arg)
